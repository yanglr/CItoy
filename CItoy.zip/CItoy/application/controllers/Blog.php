<?php

class Blog extends CI_Controller {
	function index(){
		// echo 'Hello World!';
		$data['myName']="Bruce";
		$data['head']="'s Blog !";
		$data['todo']=array('eat','sleep','call');

		$this->load->view('blog_view',$data);		
	}
	function hello(){
		echo 'Hello Bruce !';
	}
}

?>
