<!-- <?php echo 'Welcome to my blog'; ?> -->
<html>
<head>
<title><?php echo $myName.$head?></title>
</head>
<body>
<h1>I am <?php echo $myName ?></h1>

<?php foreach($todo as $item){ ?>
<li><?php echo $item ?></li>
<?php } ?>

</body>
</html>
